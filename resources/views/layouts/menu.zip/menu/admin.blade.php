    
    <div id="sidebar" class="sidebar  responsive ace-save-state">

        <script type="text/javascript">

          try{ace.settings.loadState('sidebar')}catch(e){}

        </script>

        <div class="sidebar-shortcuts" id="sidebar-shortcuts">

          <div class="sidebar-shortcuts-large" id="sidebar-shortcuts-large">

            <button class="btn btn-success">

              <i class="ace-icon fa fa-signal"></i>

            </button>



            <button class="btn btn-info">

              <i class="ace-icon fa fa-pencil"></i>

            </button>



            <button class="btn btn-warning">

              <i class="ace-icon fa fa-users"></i>

            </button>



            <button class="btn btn-danger">

              <i class="ace-icon fa fa-cogs"></i>

            </button>

          </div>



          <div class="sidebar-shortcuts-mini" id="sidebar-shortcuts-mini">

            <span class="btn btn-success"></span>

            <span class="btn btn-info"></span>

            <span class="btn btn-warning"></span>

            <span class="btn btn-danger"></span>

          </div>

        </div><!-- /.sidebar-shortcuts -->



        <ul class="nav nav-list">

          <li class="active">

            <a>

              <span class="menu-text">&nbsp;&nbsp; Modulo </span>

            </a>

            <b class="arrow"></b>

          </li>

                 



                                        <li  style="padding-top:15px">

                                  <div class="dropdown">

                              <div style="padding-left:17px" class=" dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                  <span title="Maestros" style="display:inline-block" class="glyphicon glyphicon-user" aria-hidden="true"></span>

                                  

                               <div style="display:inline-block; margin-left:14px; font-size:16px" class="texto_menu">Empresas</div>

                              </div>

                                <ul id="desplegable1" class="dropdown-menu">

                                  <li><a tabindex="-1" href="/contratacion/tipos_contratos">Modalidad de Contratos</a></li>

                                  <li><a tabindex="-1" href="/contratacion/all_criterios_evaluacion">Criterios Evaluaci&oacuten</a></li>

                                  <li><a tabindex="-1" href="/contratacion/articulos_servicios">Articulos y Servicios</a></li>

                                  <li><a tabindex="-1" href="/contratacion/tipos_actas">Tipos Actas</a></li>

                                  <li><a tabindex="-1" href="/contratacion/tipos_documentos">Clases de Documentos</a></li>

                                   <li><a tabindex="-1" href="/contratacion/tipos_avances">Tipos Avances</a></li>

                                   <li><a tabindex="-1" href="/contratacion/tipos_polizas">Tipos polizas</a></li>

                                   <li><a tabindex="-1" href="/contratacion/aseguradoras">Aseguradoras</a></li>

                                   <li><a tabindex="-1" href="/contratacion/entes_control">Entes de Control</a></li>

                                   <li><a tabindex="-1" href="/contratacion/terceros">Terceros</a></li>

                                   <li><a tabindex="-1" href="/contratacion/responsables">Responsables</a></li>

                              

                                </ul>

                              </div>

          </li>

          

          

          

          <li  style="padding-top:15px">

                                  <div class="dropdown">

                              <div style="padding-left:17px" class=" dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                                  <span title="Mantenimientos" style="display:inline-block" class="glyphicon glyphicon-wrench" aria-hidden="true"></span>

                                  

                               <div style="display:none; margin-left:14px; font-size:16px" class="texto_menu">Usuarios</div>

                              </div>

                                <ul id="desplegable1" class="dropdown-menu">

                                  <li><a tabindex="-1" href="/contratacion/comite_seguimiento">Comite de Seguimiento</a></li>

                                  <li><a tabindex="-1" href="/contratacion/precontratos">Precontratos</a></li>

                                  <li><a tabindex="-1" href="/contratacion/licitaciones">Licitaciones</a></li>

                                   <li><a tabindex="-1" href="/contratacion/oferentes">Oferentes</a></li>

                                   <li><a tabindex="-1" href="/contratacion/contratos">Contratos</a></li>

                                   <li><a tabindex="-1" href="/contratacion/otrossi">OtrosSi</a></li>

                                   <li><a tabindex="-1" href="/contratacion/suspensiones">Suspensiones</a></li>

                                   <li><a tabindex="-1" href="/contratacion/reinicios">Reinicios</a></li>

                                   <li><a tabindex="-1" href="/contratacion/cesioness">Cesiones</a></li>

                                   <li><a tabindex="-1" href="/contratacion/liquidaciones">Liquidaci贸n de Contratos</a></li>

                                  

                                  

                              

                                </ul>

                              </div>

          </li>

          

          

          

          

            <li  style="padding-top:15px; display;none">

          

                <div class="dropdown">

  <div style="padding-left:17px" class=" dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

      <span title="Consultas" style="display:inline-block" class="glyphicon glyphicon-search" aria-hidden="true"></span>

      

   <div style="display:none; margin-left:14px; font-size:16px" class="texto_menu">Maestros</div>

  </div>

    <ul id="desplegable1" class="dropdown-menu">

     <li><a tabindex="-1" href="/contratacion/estado_licitaciones">ARL</a></li>

     <li><a tabindex="-1" href="/contratacion/estado_contratos">EPS</a></li>

     <li><a tabindex="-1" href="/contratacion/contratos_en_ejecucion">EPP</a></li>

     <li><a tabindex="-1" href="/contratacion/contraros_sector">PUC</a></li>

     <li><a tabindex="-1" href="/contratacion/contratos_eferente">GRUPOS</a></li>
     <li><a tabindex="-1" href="/contratacion/contratos_eferente">ELEMENTOS</a></li>
     <li><a tabindex="-1" href="/contratacion/contratos_eferente">TIPOS INGRESOS</a></li>
     <li><a tabindex="-1" href="/contratacion/contratos_eferente">TIPOS EGRESOS</a></li>
     <li><a tabindex="-1" href="/contratacion/contratos_eferente">TIPOS DE DOCUMENTOS</a></li>
     <li><a tabindex="-1" href="/contratacion/contratos_eferente">TIPOS ENFERMEDADES</a></li>
     <li><a tabindex="-1" href="/contratacion/contratos_eferente">PROFESIONES</a></li>

    </ul>

  </div>

        </ul><!-- /.nav-list -->



        <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">

          <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>

        </div>

      </div>